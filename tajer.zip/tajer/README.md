# TAJER (تاجر) — Arabic-first B2B wholesale marketplace for Iraq

Target: approved SuperQi Mini App only. UI is Arabic/RTL; code and docs are English.

- `docs/ARCHITECTURE.md` — system design, security model, SuperQi isolation
- `docs/FEATURE_MAP.md` — every feature, portal and milestone
- `docs/DATABASE.md` — full data model
- `docs/ROADMAP.md` — milestones and acceptance criteria
- `supabase/migrations/` — database migrations (apply in order)
- `supabase/tests/` — database security tests (pgTAP)

Status: Milestone 1 (foundation) database layer written; NOT yet applied to a real database or tested.
No SuperQi integration exists. Nothing here claims SuperQi approval.

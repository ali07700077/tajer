-- pgTAP security tests for migration 001. NOT YET RUN — run on staging after applying the migration.
-- Run with: supabase test db   (requires Supabase CLI). The file ends in ROLLBACK, so it leaves no data.
begin;
create extension if not exists pgtap with schema extensions;
set search_path = public, extensions;
select plan(11);

insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-0000000000a1', 'buyer-a@test.local'),
  ('00000000-0000-0000-0000-0000000000b2', 'supplier-b@test.local');

create or replace function pg_temp.act_as(p_uid uuid) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_uid, 'role', 'authenticated')::text, true);
  set local role authenticated;
end $$;

-- A and B each create a business
select pg_temp.act_as('00000000-0000-0000-0000-0000000000a1');
select lives_ok(
  $$select public.create_business('buyer', 'متجر الأمل', (select id from public.governorates where code = 'baghdad'))$$,
  'A can create a buyer business');
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000b2');
select lives_ok(
  $$select public.create_business('supplier', 'شركة النور للجملة', (select id from public.governorates where code = 'baghdad'))$$,
  'B can create a supplier business');

-- Tenant isolation
reset role;
select pg_temp.act_as('00000000-0000-0000-0000-0000000000a1');
select is((select count(*)::int from public.businesses), 1, 'A sees only own business');
select is(
  (with u as (update public.businesses set name_ar = 'اختراق'
              where business_type = 'supplier' returning 1) select count(*)::int from u),
  0, 'A cannot update B''s business');

-- Privilege escalation
select throws_ok(
  $$update public.businesses set verification_status = 'approved'$$,
  '42501', null, 'owner cannot self-approve (column privilege)');
select throws_ok(
  $$insert into public.businesses (business_type, name_ar, governorate_id)
    values ('supplier', 'مزور', (select id from public.governorates limit 1))$$,
  '42501', null, 'clients cannot insert businesses directly');
select throws_ok(
  $$insert into public.categories (slug, name_ar) values ('hack', 'اختراق')$$,
  '42501', null, 'non-staff cannot create categories');
select is((select count(*)::int from public.audit_logs), 0, 'non-staff sees no audit logs');
select throws_ok(
  $$select public.write_audit_log('fake', 'x', null)$$,
  '42501', null, 'clients cannot write audit logs');

-- Public catalog data readable by anon
reset role;
set local role anon;
select ok((select count(*) from public.categories) > 0, 'anon can read active categories');

-- Append-only audit log
reset role;
select throws_ok(
  $$update public.audit_logs set action = 'tampered'$$,
  'P0001', 'audit_logs is append-only', 'audit log cannot be modified');

select * from finish();
rollback;

-- =====================================================================
-- TAJER — Migration 001: Foundation
-- Profiles, RBAC (roles/permissions), geography, categories,
-- businesses + membership, append-only audit log, Row Level Security.
--
-- STATUS: written but NOT yet executed against a real database.
-- Run it first on the STAGING project, then run supabase/tests.
--
-- Conventions for ALL future migrations:
--   * every table: uuid PK, created_at/updated_at, RLS enabled
--   * clients get NO privileges by default: grant explicitly, per table/column
--   * writes to sensitive state go through SECURITY DEFINER functions (RPC)
--   * technical errors stay English; the app maps error codes to Arabic text
-- =====================================================================

-- ---------- Types ----------------------------------------------------
create type public.business_type as enum ('buyer', 'supplier');
create type public.verification_status as enum
  ('draft', 'submitted', 'under_review', 'approved', 'rejected', 'suspended');
create type public.member_role as enum ('owner', 'manager', 'staff');
create type public.account_status as enum ('active', 'suspended');

-- ---------- Generic helpers ------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------- Tables ---------------------------------------------------

-- One profile per Supabase auth user (auth.users is managed by Supabase Auth).
create table public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text check (full_name is null or char_length(full_name) <= 120),
  phone       text check (phone is null or phone ~ '^[0-9+ ()-]{6,20}$'),
  status      public.account_status not null default 'active',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

-- Staff RBAC. Roles are data, so admins can define new roles without code changes.
create table public.roles (
  id              uuid primary key default gen_random_uuid(),
  key             text not null unique check (key ~ '^[a-z][a-z0-9_]*$'),
  name_ar         text not null,
  description_ar  text,
  is_system       boolean not null default false,
  created_at      timestamptz not null default now()
);

create table public.permissions (
  key       text primary key check (key ~ '^[a-z][a-z0-9_]*\.[a-z][a-z0-9_]*$'),
  name_ar   text not null,
  group_key text not null
);

create table public.role_permissions (
  role_id        uuid not null references public.roles (id) on delete cascade,
  permission_key text not null references public.permissions (key) on delete cascade,
  primary key (role_id, permission_key)
);

create table public.staff_roles (
  user_id     uuid not null references public.profiles (id) on delete cascade,
  role_id     uuid not null references public.roles (id) on delete cascade,
  granted_by  uuid references public.profiles (id) on delete set null,
  created_at  timestamptz not null default now(),
  primary key (user_id, role_id)
);
create index staff_roles_role_idx on public.staff_roles (role_id);

-- Geography: configurable, so expansion beyond Baghdad needs no code change.
create table public.governorates (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique check (code ~ '^[a-z][a-z0-9-]*$'),
  name_ar     text not null,
  name_en     text,
  is_active   boolean not null default false,
  sort_order  integer not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger governorates_set_updated_at before update on public.governorates
  for each row execute function public.set_updated_at();

create table public.cities (
  id             uuid primary key default gen_random_uuid(),
  governorate_id uuid not null references public.governorates (id) on delete restrict,
  name_ar        text not null,
  name_en        text,
  is_active      boolean not null default true,
  sort_order     integer not null default 0,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (governorate_id, name_ar)
);
create index cities_governorate_idx on public.cities (governorate_id);
create trigger cities_set_updated_at before update on public.cities
  for each row execute function public.set_updated_at();

-- Categories: unlimited depth tree, any wholesale sector.
create table public.categories (
  id              uuid primary key default gen_random_uuid(),
  parent_id       uuid references public.categories (id) on delete restrict,
  slug            text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name_ar         text not null,
  name_en         text,
  description_ar  text,
  icon            text,
  image_path      text,
  sort_order      integer not null default 0,
  is_active       boolean not null default true,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint categories_not_own_parent check (parent_id is null or parent_id <> id)
);
create index categories_parent_idx on public.categories (parent_id);
create trigger categories_set_updated_at before update on public.categories
  for each row execute function public.set_updated_at();

create or replace function public.categories_prevent_cycle()
returns trigger language plpgsql set search_path = '' as $$
begin
  if new.parent_id is null then
    return new;
  end if;
  if exists (
    with recursive ancestors as (
      select c.id, c.parent_id from public.categories c where c.id = new.parent_id
      union all
      select c.id, c.parent_id from public.categories c
      join ancestors a on c.id = a.parent_id
    )
    select 1 from ancestors where id = new.id
  ) then
    raise exception 'category hierarchy cannot contain a cycle' using errcode = '23514';
  end if;
  return new;
end $$;
create trigger categories_prevent_cycle before insert or update of parent_id on public.categories
  for each row execute function public.categories_prevent_cycle();

-- Businesses: a buyer or supplier company. Users belong via business_members (multi-user ready).
create table public.businesses (
  id                          uuid primary key default gen_random_uuid(),
  business_type               public.business_type not null,
  name_ar                     text not null check (char_length(trim(name_ar)) between 2 and 160),
  name_en                     text check (name_en is null or char_length(name_en) <= 160),
  legal_name                  text,
  commercial_registration_no  text,
  tax_id                      text,
  governorate_id              uuid not null references public.governorates (id) on delete restrict,
  city_id                     uuid references public.cities (id) on delete restrict,
  address_text                text,
  phone                       text check (phone is null or phone ~ '^[0-9+ ()-]{6,20}$'),
  email                       text,
  description_ar              text,
  logo_path                   text,
  verification_status         public.verification_status not null default 'draft',
  verification_reason         text,
  reviewed_by                 uuid references public.profiles (id) on delete set null,
  reviewed_at                 timestamptz,
  is_active                   boolean not null default true,
  created_by                  uuid references public.profiles (id) on delete set null,
  created_at                  timestamptz not null default now(),
  updated_at                  timestamptz not null default now()
);
create index businesses_type_status_idx on public.businesses (business_type, verification_status);
create index businesses_governorate_idx on public.businesses (governorate_id);
create trigger businesses_set_updated_at before update on public.businesses
  for each row execute function public.set_updated_at();

create or replace function public.businesses_validate_city()
returns trigger language plpgsql set search_path = '' as $$
begin
  if new.city_id is not null and not exists (
    select 1 from public.cities c
    where c.id = new.city_id and c.governorate_id = new.governorate_id
  ) then
    raise exception 'city does not belong to the selected governorate' using errcode = '23514';
  end if;
  return new;
end $$;
create trigger businesses_validate_city before insert or update of city_id, governorate_id
  on public.businesses for each row execute function public.businesses_validate_city();

create table public.business_members (
  business_id  uuid not null references public.businesses (id) on delete cascade,
  user_id      uuid not null references public.profiles (id) on delete cascade,
  member_role  public.member_role not null default 'staff',
  created_at   timestamptz not null default now(),
  primary key (business_id, user_id)
);
create index business_members_user_idx on public.business_members (user_id);

-- Append-only audit log.
create table public.audit_logs (
  id           uuid primary key default gen_random_uuid(),
  actor_id     uuid,  -- intentionally no FK: logs must outlive users
  action       text not null,
  entity_type  text,
  entity_id    uuid,
  reason       text,
  metadata     jsonb not null default '{}'::jsonb,
  created_at   timestamptz not null default now()
);
create index audit_logs_created_idx on public.audit_logs (created_at desc);
create index audit_logs_entity_idx  on public.audit_logs (entity_type, entity_id);
create index audit_logs_actor_idx   on public.audit_logs (actor_id);

create or replace function public.audit_logs_block_changes()
returns trigger language plpgsql set search_path = '' as $$
begin
  raise exception 'audit_logs is append-only';
end $$;
create trigger audit_logs_no_update_delete before update or delete on public.audit_logs
  for each row execute function public.audit_logs_block_changes();
create trigger audit_logs_no_truncate before truncate on public.audit_logs
  for each statement execute function public.audit_logs_block_changes();

-- ---------- Security helper functions --------------------------------

-- Super admin implicitly holds every permission.
create or replace function public.has_permission(p_key text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.staff_roles sr
    join public.roles r on r.id = sr.role_id
    where sr.user_id = auth.uid() and r.key = 'super_admin'
  ) or exists (
    select 1 from public.staff_roles sr
    join public.role_permissions rp on rp.role_id = sr.role_id
    where sr.user_id = auth.uid() and rp.permission_key = p_key
  );
$$;

-- For the UI only (to show/hide menus). Real enforcement stays in RLS/RPC.
create or replace function public.my_permissions()
returns text[] language sql stable security definer set search_path = '' as $$
  select coalesce(array_agg(distinct p.key order by p.key), '{}'::text[])
  from public.permissions p
  where exists (
          select 1 from public.staff_roles sr
          join public.roles r on r.id = sr.role_id
          where sr.user_id = auth.uid() and r.key = 'super_admin')
     or exists (
          select 1 from public.staff_roles sr
          join public.role_permissions rp on rp.role_id = sr.role_id
          where sr.user_id = auth.uid() and rp.permission_key = p.key);
$$;

create or replace function public.is_business_member(p_business_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.business_members m
    where m.business_id = p_business_id and m.user_id = auth.uid()
  );
$$;

create or replace function public.has_business_role(p_business_id uuid, p_roles public.member_role[])
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.business_members m
    where m.business_id = p_business_id and m.user_id = auth.uid()
      and m.member_role = any (p_roles)
  );
$$;

-- Internal only (not callable by clients).
create or replace function public.write_audit_log(
  p_action text, p_entity_type text, p_entity_id uuid,
  p_reason text default null, p_metadata jsonb default '{}'::jsonb)
returns void language sql security definer set search_path = '' as $$
  insert into public.audit_logs (actor_id, action, entity_type, entity_id, reason, metadata)
  values (auth.uid(), p_action, p_entity_type, p_entity_id, p_reason, coalesce(p_metadata, '{}'::jsonb));
$$;

-- Generic row-change auditing (stores WHICH columns changed, never the values).
create or replace function public.audit_row_change()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  v_row     jsonb;
  v_changed jsonb;
  v_meta    jsonb := '{}'::jsonb;
begin
  if tg_op = 'DELETE' then
    v_row := to_jsonb(old);
  else
    v_row := to_jsonb(new);
  end if;

  if tg_op = 'UPDATE' then
    select coalesce(jsonb_agg(n.key order by n.key), '[]'::jsonb) into v_changed
    from jsonb_each(to_jsonb(new)) n
    join jsonb_each(to_jsonb(old)) o on o.key = n.key
    where n.value is distinct from o.value and n.key <> 'updated_at';
    if v_changed = '[]'::jsonb then
      return new;
    end if;
    v_meta := jsonb_build_object('changed_columns', v_changed);
  elsif tg_table_name = 'staff_roles' then
    v_meta := v_row;
  end if;

  perform public.write_audit_log(
    tg_table_name || '.' || lower(tg_op), tg_table_name,
    nullif(v_row ->> 'id', '')::uuid, null, v_meta);

  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end $$;

create trigger audit_categories   after insert or update or delete on public.categories
  for each row execute function public.audit_row_change();
create trigger audit_governorates after insert or update or delete on public.governorates
  for each row execute function public.audit_row_change();
create trigger audit_cities       after insert or update or delete on public.cities
  for each row execute function public.audit_row_change();
create trigger audit_businesses   after insert or update or delete on public.businesses
  for each row execute function public.audit_row_change();
create trigger audit_staff_roles  after insert or update or delete on public.staff_roles
  for each row execute function public.audit_row_change();

-- ---------- Auth hooks / RPC -----------------------------------------

-- Every new auth user automatically gets a profile (no staff role, ever).
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, nullif(left(new.raw_user_meta_data ->> 'full_name', 120), ''));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Clients cannot INSERT into businesses directly; this is the only path.
-- Creates the business as DRAFT and makes the caller its owner, atomically.
create or replace function public.create_business(
  p_business_type  public.business_type,
  p_name_ar        text,
  p_governorate_id uuid,
  p_city_id        uuid default null,
  p_phone          text default null)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_id uuid;
begin
  if auth.uid() is null then
    raise exception 'not authenticated' using errcode = '28000';
  end if;
  if not exists (select 1 from public.profiles where id = auth.uid() and status = 'active') then
    raise exception 'account is not active' using errcode = '42501';
  end if;
  if char_length(trim(coalesce(p_name_ar, ''))) < 2 then
    raise exception 'business name is required' using errcode = '22023';
  end if;
  if not exists (select 1 from public.governorates where id = p_governorate_id and is_active) then
    raise exception 'governorate is not available' using errcode = '22023';
  end if;
  if (select count(*) from public.business_members
      where user_id = auth.uid() and member_role = 'owner') >= 3 then
    raise exception 'business limit reached' using errcode = '54000';
  end if;

  insert into public.businesses (business_type, name_ar, governorate_id, city_id, phone, created_by)
  values (p_business_type, trim(p_name_ar), p_governorate_id, p_city_id, p_phone, auth.uid())
  returning id into v_id;

  insert into public.business_members (business_id, user_id, member_role)
  values (v_id, auth.uid(), 'owner');

  return v_id;
end $$;

-- ---------- Seed: permissions and roles ------------------------------
insert into public.permissions (key, name_ar, group_key) values
  ('users.read',        'عرض المستخدمين',               'users'),
  ('users.manage',      'إدارة المستخدمين',             'users'),
  ('businesses.read',   'عرض الأعمال التجارية',         'businesses'),
  ('businesses.review', 'مراجعة وتوثيق الأعمال',        'businesses'),
  ('businesses.suspend','إيقاف الأعمال التجارية',       'businesses'),
  ('documents.read',    'عرض المستندات الخاصة',         'businesses'),
  ('categories.manage', 'إدارة التصنيفات',              'catalog'),
  ('products.moderate', 'مراجعة المنتجات',              'catalog'),
  ('geo.manage',        'إدارة المحافظات والمدن',       'settings'),
  ('rfqs.read',         'عرض طلبات الأسعار',            'trade'),
  ('offers.read',       'عرض العروض',                   'trade'),
  ('orders.read',       'عرض الطلبات',                  'trade'),
  ('orders.manage',     'إدارة الطلبات',                'trade'),
  ('tickets.manage',    'إدارة الدعم الفني',            'support'),
  ('banners.manage',    'إدارة البانرات والإعلانات',    'content'),
  ('settings.manage',   'إدارة إعدادات المنصة',         'settings'),
  ('roles.manage',      'إدارة الأدوار والصلاحيات',     'settings'),
  ('audit.read',        'عرض سجل التدقيق',              'security'),
  ('reports.read',      'عرض التقارير',                 'reports'),
  ('reports.export',    'تصدير التقارير',               'reports');

insert into public.roles (key, name_ar, description_ar, is_system) values
  ('super_admin',           'المدير العام',        'صلاحيات كاملة على المنصة',              true),
  ('admin',                 'مدير',                'إدارة المنصة بدون إدارة الأدوار',        true),
  ('verification_reviewer', 'مراجع التوثيق',       'مراجعة مستندات الموردين',               true),
  ('catalog_moderator',     'مشرف الكتالوج',       'مراجعة التصنيفات والمنتجات',             true),
  ('support_agent',         'موظف الدعم',          'الدعم الفني ومتابعة الطلبات',            true);

insert into public.role_permissions (role_id, permission_key)
select r.id, p.key
from public.roles r
join public.permissions p on (
     (r.key = 'admin' and p.key <> 'roles.manage')
  or (r.key = 'verification_reviewer'
        and p.key in ('businesses.read', 'businesses.review', 'documents.read'))
  or (r.key = 'catalog_moderator'
        and p.key in ('categories.manage', 'products.moderate', 'businesses.read'))
  or (r.key = 'support_agent'
        and p.key in ('users.read', 'businesses.read', 'tickets.manage',
                      'rfqs.read', 'offers.read', 'orders.read'))
);

-- ---------- Seed: Iraqi governorates (only Baghdad active for the pilot) ----
insert into public.governorates (code, name_ar, name_en, is_active, sort_order) values
  ('baghdad',      'بغداد',    'Baghdad',       true,   1),
  ('basra',        'البصرة',   'Basra',         false,  2),
  ('nineveh',      'نينوى',    'Nineveh',       false,  3),
  ('erbil',        'أربيل',    'Erbil',         false,  4),
  ('sulaymaniyah', 'السليمانية','Sulaymaniyah', false,  5),
  ('duhok',        'دهوك',     'Duhok',         false,  6),
  ('kirkuk',       'كركوك',    'Kirkuk',        false,  7),
  ('anbar',        'الأنبار',  'Anbar',         false,  8),
  ('diyala',       'ديالى',    'Diyala',        false,  9),
  ('salahuddin',   'صلاح الدين','Salah al-Din', false, 10),
  ('babil',        'بابل',     'Babil',         false, 11),
  ('karbala',      'كربلاء',   'Karbala',       false, 12),
  ('najaf',        'النجف',    'Najaf',         false, 13),
  ('qadisiyyah',   'القادسية', 'Al-Qadisiyyah', false, 14),
  ('wasit',        'واسط',     'Wasit',         false, 15),
  ('maysan',       'ميسان',    'Maysan',        false, 16),
  ('dhi-qar',      'ذي قار',   'Dhi Qar',       false, 17),
  ('muthanna',     'المثنى',   'Al-Muthanna',   false, 18);

-- A few Baghdad areas as a starting point; admins can edit these in the dashboard.
insert into public.cities (governorate_id, name_ar, name_en, sort_order)
select g.id, v.name_ar, v.name_en, v.sort_order
from public.governorates g
cross join (values
  ('الكرادة',     'Karrada',    1),
  ('المنصور',     'Mansour',    2),
  ('الأعظمية',    'Adhamiya',   3),
  ('الكاظمية',    'Kadhimiya',  4),
  ('مدينة الصدر', 'Sadr City',  5),
  ('الدورة',      'Dora',       6)
) as v (name_ar, name_en, sort_order)
where g.code = 'baghdad';

-- ---------- Seed: pilot category tree (editable; not a limit) ----------
insert into public.categories (slug, name_ar, name_en, sort_order)
values ('mobile-accessories', 'إكسسوارات الموبايل', 'Mobile accessories', 1);

insert into public.categories (parent_id, slug, name_ar, name_en, sort_order)
select p.id, v.slug, v.name_ar, v.name_en, v.sort_order
from public.categories p
cross join (values
  ('chargers-cables',   'شواحن وكيبلات',             'Chargers & cables',        1),
  ('power-banks',       'بنوك الطاقة',               'Power banks',              2),
  ('headphones',        'سماعات',                    'Headphones & earbuds',     3),
  ('cases-protectors',  'حافظات وواقيات الشاشة',      'Cases & screen protectors',4),
  ('storage-cards',     'ذاكرة وفلاشات',             'Memory & storage',         5),
  ('holders-car',       'حوامل وملحقات السيارة',      'Holders & car accessories',6)
) as v (slug, name_ar, name_en, sort_order)
where p.slug = 'mobile-accessories';

-- ---------- Row Level Security ---------------------------------------
alter table public.profiles          enable row level security;
alter table public.roles             enable row level security;
alter table public.permissions       enable row level security;
alter table public.role_permissions  enable row level security;
alter table public.staff_roles       enable row level security;
alter table public.governorates      enable row level security;
alter table public.cities            enable row level security;
alter table public.categories        enable row level security;
alter table public.businesses        enable row level security;
alter table public.business_members  enable row level security;
alter table public.audit_logs        enable row level security;

-- profiles
create policy profiles_select_own   on public.profiles for select to authenticated
  using (id = auth.uid());
create policy profiles_select_staff on public.profiles for select to authenticated
  using (public.has_permission('users.read'));
create policy profiles_update_own   on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- RBAC tables (read-only for clients; changes via SQL/RPC by super admin)
create policy roles_select on public.roles for select to authenticated
  using (public.has_permission('roles.manage'));
create policy permissions_select on public.permissions for select to authenticated
  using (public.has_permission('roles.manage'));
create policy role_permissions_select on public.role_permissions for select to authenticated
  using (public.has_permission('roles.manage'));
create policy staff_roles_select on public.staff_roles for select to authenticated
  using (user_id = auth.uid() or public.has_permission('roles.manage'));

-- geography + categories: active rows public; staff manage
create policy governorates_public_read on public.governorates for select to anon, authenticated
  using (is_active);
create policy governorates_staff_all   on public.governorates for all to authenticated
  using (public.has_permission('geo.manage')) with check (public.has_permission('geo.manage'));

create policy cities_public_read on public.cities for select to anon, authenticated
  using (is_active);
create policy cities_staff_all   on public.cities for all to authenticated
  using (public.has_permission('geo.manage')) with check (public.has_permission('geo.manage'));

create policy categories_public_read on public.categories for select to anon, authenticated
  using (is_active);
create policy categories_staff_all   on public.categories for all to authenticated
  using (public.has_permission('categories.manage'))
  with check (public.has_permission('categories.manage'));

-- businesses: members see their own; staff with permission see all.
-- No client INSERT/DELETE. UPDATE limited to owner/manager and to safe columns.
create policy businesses_select_member on public.businesses for select to authenticated
  using (public.is_business_member(id));
create policy businesses_select_staff  on public.businesses for select to authenticated
  using (public.has_permission('businesses.read'));
create policy businesses_update_member on public.businesses for update to authenticated
  using (public.has_business_role(id, array['owner', 'manager']::public.member_role[])
         and verification_status <> 'suspended')
  with check (public.has_business_role(id, array['owner', 'manager']::public.member_role[]));

create policy business_members_select on public.business_members for select to authenticated
  using (public.is_business_member(business_id) or public.has_permission('businesses.read'));

-- audit log: readable only with audit.read; nobody writes directly
create policy audit_logs_select on public.audit_logs for select to authenticated
  using (public.has_permission('audit.read'));

-- ---------- Privileges (default-deny, then explicit grants) ----------
revoke all on all tables in schema public from anon, authenticated;

grant select on public.governorates, public.cities, public.categories to anon, authenticated;
grant insert, update, delete on public.governorates, public.cities, public.categories to authenticated;

grant select on public.profiles, public.roles, public.permissions, public.role_permissions,
               public.staff_roles, public.businesses, public.business_members,
               public.audit_logs to authenticated;

-- Column-level UPDATE: sensitive columns (status, verification_*, is_active, created_by) are excluded.
grant update (full_name, phone) on public.profiles to authenticated;
grant update (name_ar, name_en, legal_name, commercial_registration_no, tax_id, governorate_id,
              city_id, address_text, phone, email, description_ar, logo_path)
  on public.businesses to authenticated;

-- Function privileges
revoke all on function public.has_permission(text)                          from public, anon, authenticated;
revoke all on function public.my_permissions()                              from public, anon, authenticated;
revoke all on function public.is_business_member(uuid)                      from public, anon, authenticated;
revoke all on function public.has_business_role(uuid, public.member_role[]) from public, anon, authenticated;
revoke all on function public.create_business(public.business_type, text, uuid, uuid, text)
                                                                            from public, anon, authenticated;
revoke all on function public.write_audit_log(text, text, uuid, text, jsonb) from public, anon, authenticated;

grant execute on function public.has_permission(text)                          to authenticated;
grant execute on function public.my_permissions()                              to authenticated;
grant execute on function public.is_business_member(uuid)                      to authenticated;
grant execute on function public.has_business_role(uuid, public.member_role[]) to authenticated;
grant execute on function public.create_business(public.business_type, text, uuid, uuid, text)
                                                                               to authenticated;

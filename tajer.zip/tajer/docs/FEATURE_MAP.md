# TAJER Feature Map  (M = milestone; all start as NOT BUILT unless marked)

| Area | Feature | M | Status |
|---|---|---|---|
| Foundation | Email/password auth (dev adapter), profiles | 1 | DB written |
| Foundation | Staff roles/permissions, audit log, RLS | 1 | DB written, untested |
| Foundation | Governorates, cities, category tree (configurable) | 1 | DB written |
| Foundation | Arabic RTL app shell, routing, error/empty/loading states | 1 | not built |
| Supplier | Business profile, multi-user membership | 2 | partial (DB) |
| Supplier | Private verification documents + status workflow | 2 | not built |
| Supplier | Product CRUD, images, brand, SKU, specs, MOQ, stock status | 2 | not built |
| Supplier | Tiered pricing with validated ranges | 2 | not built |
| Supplier | Delivery areas | 2 | not built |
| Admin | Verification review (approve/reject/suspend with reason) | 2 | not built |
| Buyer | Home, categories, Arabic search, filters, product page, supplier page | 3 | not built |
| Buyer | Favorites | 3 | not built |
| Trade | RFQ create/send to selected or eligible suppliers | 4 | not built |
| Trade | Supplier offers: submit/revise/withdraw, itemized | 4 | not built |
| Trade | Offer comparison, negotiation messages, accept | 4 | not built |
| Orders | Order request from offer, price snapshot, supplier confirmation | 5 | not built |
| Orders | Status workflow + history (actor/time/reason), reorder | 5 | not built |
| Admin | Dashboard metrics, users/businesses, moderation | 5 | not built |
| Admin | Banners, announcements, settings, geography, roles UI | 5 | not built |
| Admin | Support tickets/complaints | 5 | not built |
| Admin | Reports + CSV export (permissioned, audited) | 5 | not built |
| Notifications | In-app notifications (+ email later) | 4-5 | not built |
| Quality | Cross-tenant security tests, rate limits, MFA, CSP | 6 | tests drafted |
| Platform | SuperQi adapter, submission, review | 7 | blocked on official docs |
| Future | Subscriptions, commissions, promotions, logistics, payments, AI, reviews | 8+ | designed only |

Explicitly NOT in MVP (per spec): wallet, escrow, credit, payment gateway, driver tracking, group buying, auctions, ERP. No fake payment is ever shown.

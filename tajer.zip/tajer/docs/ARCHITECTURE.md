# TAJER Architecture

## Principles
1. Owner controls everything: GitHub, Supabase, hosting, domain, platform accounts.
2. Security lives in the database (RLS + column grants + RPC), never only in the UI.
3. SuperQi-specific code is isolated behind a `PlatformAdapter`; nothing claims SuperQi integration until official docs, credentials and approval exist.
4. Multi-sector by data, not code: categories, geography, roles and settings are tables.
5. Arabic/RTL is the product; English is only code and docs.

## Layers
```
SuperQi container (future)  ->  Web app (React + TS + Vite + Tailwind, RTL, Arabic only)
                                   |  PlatformAdapter  (dev adapter now; SuperQi adapter later)
                                   v
                          Supabase: Auth | PostgREST (RLS) | RPC functions | Storage (private) | Edge Functions
                                   v
                              PostgreSQL (migrations in git)
```

## PlatformAdapter (isolation boundary)
Interface: `getSession()`, `signIn()`, `signOut()`, `requestPayment()` (disabled), `notify()` (in-app only), `share()`.
- `DevAdapter`: email + password via Supabase Auth, visibly labelled "نسخة تطوير".
- `SuperQiAdapter`: NOT implemented. Built only after the owner supplies official documentation and approval.

## Security model
- Staff: RBAC (`roles` / `permissions` / `staff_roles`); `has_permission()` checked in RLS and RPC. Super admin = all.
- Tenants: `business_members` links users to businesses; policies use `is_business_member()` / `has_business_role()`.
- Clients get no table privileges by default; explicit grants only; sensitive columns excluded from UPDATE grants.
- State changes (verification, order status, offer acceptance) happen only in SECURITY DEFINER RPCs that validate actor, state transition and write history + audit.
- Private documents: private Storage bucket, path `business_id/...`, policies by membership or `documents.read`; short-lived signed URLs only.
- Audit log: append-only (trigger-enforced), readable with `audit.read`.
- Secrets: only anon key in the client; service-role key never in the browser or git.
- Also required (milestone 6): rate limiting, admin MFA, upload type/size validation, CSP, XSS-safe rendering.

## Environments
`staging` (Supabase project 1) and `production` (project 2), separate keys, same migrations. Production on a paid plan for daily backups and PITR evaluation.

## Extension points (designed, not built yet)
Subscriptions, commissions, promotions (own tables + settings), logistics (shipments linked to orders), payments (behind adapter, only with approved provider), AI features (separate Edge Functions reading permitted data).

## Open SuperQi unknowns (owner must obtain)
Official SDK docs; how users authenticate and what identity is returned; allowed domains/CSP; file upload/camera support; notification API; payment API and merchant approval; review process, branding rules, hosting/data-residency requirements.

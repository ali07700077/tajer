# TAJER Roadmap

| M | Scope | Done when |
|---|---|---|
| 0 | Accounts (GitHub, Supabase staging), repo, docs | Owner owns repo + staging project |
| 1 | Foundation: migration 001 applied, tests pass, Arabic RTL shell, sign-up/sign-in, first Super Admin | Acceptance #11 shell; RLS tests green |
| 2 | Supplier onboarding, private docs, admin review, product/price-tier management | Acceptance #2,3,4,10 |
| 3 | Buyer discovery: home, categories, Arabic search, product + supplier pages, favorites | Acceptance #1 (browse/search/tiers) |
| 4 | RFQ, offers, comparison, negotiation, notifications | Acceptance #5,6 |
| 5 | Orders + status history, full admin dashboard, tickets, reports/CSV | Acceptance #7,8 |
| 6 | Security & QA: cross-tenant tests, rate limits, MFA, CSP, performance, backup/restore drill | Acceptance #9,10 + checklist |
| 7 | SuperQi adapter + submission (needs official docs/approval) | Approved by SuperQi |
| 8 | Subscriptions, commissions, promotions, logistics, payments, AI | per business decision |

Each milestone ends with: working screens on real data, automated tests, migration files, updated docs, and a simple Arabic guide for you.

# TAJER Database Design

Conventions: uuid PKs; `created_at`/`updated_at`; money as integer IQD with `currency` column (default 'IQD') for future; RLS on every table; snapshots in orders.

## M1 (migration 001 — written)
profiles, roles, permissions, role_permissions, staff_roles, governorates, cities, categories (tree), businesses (buyer|supplier), business_members, audit_logs.

## M2 — Supplier & catalog
- business_documents (private storage path, doc_type, status, reviewer)
- verification_events (status history: from/to/actor/reason)
- brands; products (business_id, category_id, brand_id, sku, name_ar, description_ar, specs jsonb, moq, stock_status, is_active, moderation_status)
- category_attributes (per-category spec definitions -> any sector without code changes)
- product_images; price_tiers (min_qty, max_qty, unit_price_iqd; exclusion constraint prevents overlaps)
- supplier_delivery_areas (business_id, governorate_id, city_id, eta_days)
- Arabic search: normalized text column + trigram index (normalize alef/yaa/taa marbuta, strip tashkeel)

## M3 — Buyer: favorites; public read views exposing only safe supplier/product columns.

## M4 — Trade
rfqs, rfq_items, rfq_recipients (who may see an RFQ), offers (versioned), offer_items, offer_messages (negotiation), notifications.

## M5 — Orders & admin
orders, order_items (snapshot name/price/qty), order_status_history (actor, time, reason), support_tickets (+ messages), banners, announcements, platform_settings, report exports log.

## Reserved for later (no tables yet)
subscriptions/plans, commissions, promotions, shipments, payments, reviews (only after completed-order rules).
